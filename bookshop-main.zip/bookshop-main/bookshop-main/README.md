```
python manage.py runserver
```
   


