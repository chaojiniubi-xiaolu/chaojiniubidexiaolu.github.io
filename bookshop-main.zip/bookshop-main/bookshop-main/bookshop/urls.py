from django.contrib import admin
from django.urls import path,include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('login.urls')),
    path('',include('main.urls')),
    path('',include('manage.urls')),
]

urlpatterns += staticfiles_urlpatterns()
