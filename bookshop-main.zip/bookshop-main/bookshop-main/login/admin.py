from django.contrib import admin
from .models import User, Manager

admin.site.register(User)
admin.site.register(Manager)